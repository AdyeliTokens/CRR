USE [MXReports]
GO

/****** Object:  StoredProcedure [dbo].[CRR_WorkCenter]    Script Date: 22/10/2018 11:33:36 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Flores, Adriana
-- Create date: Agust, 2018
-- Description:	Fast Shift Data, CRR
-- =============================================
CREATE PROCEDURE [dbo].[CRR_WorkCenter]
	
AS
BEGIN
	SET NOCOUNT ON;

    SELECT Substring(WorkCenter, 2,len(WorkCenter)) WorkCenter
      ,TextID
      ,Facility
      ,Company
      ,ISNULL(Department,'SECONDARY 2') Department
  FROM FLX952_RC1.dbo.WORK_CENTER 
  WHERE SUBSTRING(workCenter, 1 , 1) ='P'

END

GO

