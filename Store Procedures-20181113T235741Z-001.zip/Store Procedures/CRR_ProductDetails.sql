USE [MXReports]
GO

/****** Object:  StoredProcedure [dbo].[CRR_ProductDetails]    Script Date: 22/10/2018 11:29:31 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Flores, Adriana
-- Create date: Agust, 2018
-- Description:	Fast Shift Data, CRR
-- =============================================
CREATE PROCEDURE [dbo].[CRR_ProductDetails]
	@CodeFA varchar(11)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

     Select top 1 FG_ProductID		= WO.ProductID  
		 ,FG_ProductNo		= P.ProductNo + isnull('.' + P.ProductRevision, '') 
		 ,CigareteWeight =   (select AverageValue/ 1000 from [FLX952_RC1].[dbo].[PRODUCT_DIMENSION] where ProductID = WO.ProductID and DimensionCode='UnitNetWeight' )  
	 from [FLX952_RC1].[dbo].WIP_ORDER WO  
	inner join [FLX952_RC1].[dbo].PRODUCT P  
	 on WO.ProductID = P.ID 
	 Where  P.ProductNo=@CodeFA
END


GO

