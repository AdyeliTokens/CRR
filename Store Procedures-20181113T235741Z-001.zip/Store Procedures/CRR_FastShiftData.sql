USE [MXReports]
GO

/****** Object:  StoredProcedure [dbo].[CRR_FastShiftData]    Script Date: 22/10/2018 11:28:51 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		Flores, Adriana
-- Create date: Agust, 2018
-- Description:	Fast Shift Data, CRR
-- =============================================
CREATE PROCEDURE [dbo].[CRR_FastShiftData] 
	@iFromDate datetime, @iToDate datetime
AS
BEGIN
	SET NOCOUNT ON;

	SELECT	substring(PO.WorkCenter, 2, len(PO.Workcenter)) WorkCenter, 
		PO.Department,
		SUM(ISNULL(PO.ProducedQty, 0)) ProdVol, 
		SUM(ISNULL(PO.TargetQty, 0)) TargetQty, 
		SUM(PO.Now_TargetQty2) Now_TargetQty,
		PO.OrderNo 
		,OC.[OrderStatus]
		,OC.[Cigarette]
		,OC.[CigaretteName]
		,OC.[FA]
		,OC.[FAName]
	FROM [FLX952_RC1].[dbo].[vMX_OrderQtyData_03] PO 
	LEFT JOIN [FLX952_RC1].[dbo].[vMX_OrderCharacteristics2] OC
	ON PO.OrderNo = OC.OrderNoPacker
	WHERE	1 = 1									
		AND		PO.PayDay >= @iFromDate 
		AND		PO.Payday <= @iToDate 
		AND		SUBSTRING(PO.Workcenter, 1, 1)  = 'P'
	GROUP BY PO.WorkCenter, PO.Department, PO.OrderNo 
		 ,OC.[OrderStatus]
		  ,OC.[Cigarette]
		  ,OC.[CigaretteName]
		  ,OC.[FA]
		  ,OC.[FAName]     
	ORDER BY PO.Workcenter

	
END





GO

