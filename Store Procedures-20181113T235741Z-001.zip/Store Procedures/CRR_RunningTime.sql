USE [MXReports]
GO

/****** Object:  StoredProcedure [dbo].[CRR_RunningTime]    Script Date: 22/10/2018 11:31:23 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Flores, Adriana
-- Create date: August, 2018
-- Description:	CRR_RunningTime
-- =============================================
CREATE PROCEDURE [dbo].[CRR_RunningTime]
	@iFromDate Datetime, @iToDate Datetime
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT  CASE Substring(WorkCenter,1,1)
			 WHEN 'F' THEN WorkCenter
			 ELSE Substring(WorkCenter,2,len(WorkCenter))
		END 'WorkCenter'
		,CASE Substring(WorkCenter,1,1)
			 WHEN 'P' THEN 'Packer'
			 WHEN 'M' THEN 'Maker'
			 WHEN 'F' THEN 'Filter'
		 END 'Type' 
		,Sum(RunningTime) RunningTime
		,ShiftNo
		,Shift
		,DATEPART( wk, @iFromDate) WeekNo 
  FROM [MXReports].[dbo].[vMX_UptimeData]
  Where PayDay between @iFromDate and @iToDate
  AND Substring(WorkCenter,1,1) in ('M','P') and Substring(WorkCenter,1,4) not in ('MULF')
  GROUP BY WorkCenter,ShiftNo,Shift
  ORDER BY WorkCenter, ShiftNo
    
END

GO

