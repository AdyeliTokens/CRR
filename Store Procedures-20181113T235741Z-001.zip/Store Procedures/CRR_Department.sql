USE [MXReports]
GO

/****** Object:  StoredProcedure [dbo].[CRR_Department]    Script Date: 22/10/2018 11:28:28 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Flores, Adriana
-- Create date: Agust, 2018
-- Description:	Fast Shift Data, CRR
-- =============================================
CREATE PROCEDURE [dbo].[CRR_Department]
	
AS
BEGIN
	SET NOCOUNT ON;

  SELECT  [Department]
      ,[Facility]
      ,[Company]
      ,[TextID]
      ,[CalendarID]
  FROM [FLX952_RC1].[dbo].[DEPARTMENT]

END

GO

