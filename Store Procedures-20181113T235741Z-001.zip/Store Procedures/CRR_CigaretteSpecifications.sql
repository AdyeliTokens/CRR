USE [MXReports]
GO

/****** Object:  StoredProcedure [dbo].[CRR_CigaretteSpecifications]    Script Date: 22/10/2018 11:26:50 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Flores, Adriana
-- Create date: October, 2018
-- Description:	Fast Shift Data, CRR
-- =============================================
CREATE PROCEDURE [dbo].[CRR_CigaretteSpecifications]
	@iOrderNo varchar(12)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @CRRCigaretteFields TABLE(BrandCode nvarchar(20),
							BrandName nvarchar(50),
							CigaretteCode nvarchar(50),
							CigaretteName nvarchar(50),
							Alternative nvarchar(10),
							ProductVersion nvarchar(10),
							Market nvarchar(10),
							Destination nvarchar(20),
							ChangeNumber nvarchar(20),
							LogoCode nvarchar(50),
							RegionalRevision nvarchar(10),
							LocalRevision nvarchar(10),
							Linkup nvarchar(10),
							RippingGroup nvarchar(20),
							EffectivityFromDate Datetime,
							CutFiller nvarchar(10),
							TippingFiller nvarchar(10),
							DCD nvarchar(10),
							LaserPerforation nvarchar(3),
							MaterialDescription varchar(50))

		-- Select values from PO Characteristics
		-- Note that the linkupID is collected from the po header
		INSERT INTO @CRRCigaretteFields
		SELECT 
			H.Brand,
			H.BrandName,
			CASE WHEN( (C.ZPPPI_SPA_CIGARETTE IS NULL) OR (len(C.ZPPPI_SPA_CIGARETTE) = 0))THEN
							 H.brand
					  ELSE C.ZPPPI_SPA_CIGARETTE
			   END ,

			C.ZPPPI_CIG_SHORT_TEXT,
			C.ZPPPI_CIG_BOM_ALT,
			C.ZPPPI_PRODUCTION_VERSION,
			C.ZPPPI_ORIG_DESIGH_MARKET,
			C.ZPPPI_DESTINATION_DESC,
			C.ZPPPI_CIG_CHANGE_NUMBER,
			C.ZPPPI_CIG_LGO_COD_1,
			C.ZPPPI_CIG_ISS_VERSION,
			C.ZPPPI_CIG_LOCAL_VERSION,
			Substring(H.Linkup,2,LEN(H.Linkup)) Linkup,
			C.ZPPPI_SHORTS_GROUP,
			--CONVERT(DateTime, C.ZPPPI_CIG_VALIDITY_DATE)
					   --Below line of code is added for CR#748344-SR#10370509-LES/MES:POD Reports Error
					  CASE WHEN C.ZPPPI_CIG_VALIDITY_DATE = '0' THEN NULL    ELSE CAST(C.ZPPPI_CIG_VALIDITY_DATE AS DATETIME) END,
			X.CutFiller,
			X.TippingFiller,
			X.DCD,
			X.LaserPerforation,
			Y.MaterialDescription
		FROM
		(	
		SELECT Characteristic, [Value]
		FROM [FLX952_RC1].[dbo].AV_RPT_PO_Characteristics
		WHERE OrderNo=@iOrderNo
		) AS X
		PIVOT
		(
		MAX(Value)
		FOR Characteristic
		IN (
			ZPPPI_SPA_CIGARETTE,
			ZPPPI_CIG_BOM_ALT,
			ZPPPI_CIG_CHANGE_NUMBER,
			ZPPPI_CIG_ISS_VERSION,
			ZPPPI_CIG_LGO_COD_1,
			ZPPPI_CIG_LOCAL_VERSION,
			ZPPPI_CIG_SHORT_TEXT,
			ZPPPI_CIG_VALIDITY_DATE,
			ZPPPI_DESTINATION_DESC,
			ZPPPI_ORIG_DESIGH_MARKET,
			ZPPPI_PRODUCTION_VERSION,
			ZPPPI_SHORTS_GROUP
			)
		) AS C,
		[FLX952_RC1].[dbo].AV_RPT_PO_Header AS H,
		(SELECT  MAX(CASE WHEN MaterialClassDesc IN ('Cut Filler /S', 'NZPROTRO') THEN MaterialCode END) CutFiller,
				MAX(CASE WHEN MaterialClassDesc = 'Tipping Paper' THEN MaterialCode END) TippingFiller,
				(SELECT	TOP 1 Value FROM [FLX952_RC1].[dbo].AV_RPT_PO_Characteristics WHERE Characteristic LIKE '%ZPPPI_CIG_LGO_COD_1%' AND OrderNo = @iOrderNo) DCD,
				(SELECT	TOP 1 Value FROM [FLX952_RC1].[dbo].AV_RPT_PO_Characteristics WHERE OrderNo=@iOrderNo AND Characteristic = 'ZPPPI_CIG_LASER_PERFORATION') LaserPerforation
		FROM    [FLX952_RC1].[dbo].AV_RPT_PO_Components_Cig
		WHERE	OrderNo = @iOrderNo
			AND MaterialClassDesc IN ('Cut Filler /S','Tipping Paper', 'NZPROTRO')) AS X,
		(
			SELECT  
			CASE WHEN MaterialDescription LIKE '%Menthol%' THEN 'RT MENTOLADO -X12' ELSE 'SIN MENTOL -X12' END as 'MaterialDescription'
			FROM         [FLX952_RC1].[dbo].AV_RPT_PO_Components_Brand
			WHERE    OrderNo = @iOrderNo and MaterialClass='P06'
		) as Y
		WHERE H.OrderNo=@iOrderNo

		SELECT * FROM @CRRCigaretteFields
END

GO


