USE [MXReports]
GO

/****** Object:  StoredProcedure [dbo].[CRR_VisualData]    Script Date: 22/10/2018 11:31:58 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Flores, Adriana
-- Create date: Agust, 2018
-- Description:	Fast Shift Data, CRR
-- =============================================
CREATE PROCEDURE [dbo].[CRR_VisualData] 
	@dtBegin datetime,@dtLast datetime
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT SUBSTRING(QD.CreatedBy,2,len(QD.CreatedBy)) 'WorkCenter', 
			COUNT(distinct QD.DispositionTestSampleID) Total,
			DATEPART( wk, @dtBegin) WeekNo, 
			CONVERT(VARCHAR(10), QD.CreatedOn, 111) DateBegin,
			CONVERT(VARCHAR(10), QD.CreatedOn, 111) DateEnd,
			CASE  WHEN    DATEPART(SECOND , QD.CreatedOn) + (DATEPART(MINUTE, QD.CreatedOn) * 60) + (DATEPART(HOUR , QD.CreatedOn) * 60 * 60) < 23400 THEN 3  
						WHEN DATEPART(SECOND , QD.CreatedOn) + (DATEPART(MINUTE, QD.CreatedOn) * 60) + (DATEPART(HOUR , QD.CreatedOn) * 60 * 60) >= 23400 AND DATEPART(SECOND , QD.CreatedOn) + (DATEPART(MINUTE, QD.CreatedOn) * 60) + (DATEPART(HOUR , QD.CreatedOn) * 60 * 60) < 52200 THEN 1  
						WHEN DATEPART(SECOND , QD.CreatedOn) + (DATEPART(MINUTE, QD.CreatedOn) * 60) + (DATEPART(HOUR , QD.CreatedOn) * 60 * 60) >= 52200 AND DATEPART(SECOND , QD.CreatedOn) + (DATEPART(MINUTE, QD.CreatedOn) * 60) + (DATEPART(HOUR , QD.CreatedOn) * 60 * 60) < 81000 THEN 2  
						ELSE 3 END  Shift
	FROM [FLX952_RC1].[dbo].[QUALITY_DEFECT] QD
	WHERE QD.CreatedOn between @dtBegin and @dtLast
		And SUBSTRING(QD.CreatedBy,1,1) ='P'
	GROUP BY QD.CreatedBy,CONVERT(VARCHAR(10), QD.CreatedOn, 111),
			CASE  WHEN DATEPART(SECOND , QD.CreatedOn) + (DATEPART(MINUTE, QD.CreatedOn) * 60) + (DATEPART(HOUR , QD.CreatedOn) * 60 * 60) < 23400 THEN 3  
					WHEN DATEPART(SECOND , QD.CreatedOn) + (DATEPART(MINUTE, QD.CreatedOn) * 60) + (DATEPART(HOUR , QD.CreatedOn) * 60 * 60) >= 23400 AND DATEPART(SECOND , QD.CreatedOn) + (DATEPART(MINUTE, QD.CreatedOn) * 60) + (DATEPART(HOUR , QD.CreatedOn) * 60 * 60) < 52200 THEN 1  
					WHEN DATEPART(SECOND , QD.CreatedOn) + (DATEPART(MINUTE, QD.CreatedOn) * 60) + (DATEPART(HOUR , QD.CreatedOn) * 60 * 60) >= 52200 AND DATEPART(SECOND , QD.CreatedOn) + (DATEPART(MINUTE, QD.CreatedOn) * 60) + (DATEPART(HOUR , QD.CreatedOn) * 60 * 60) < 81000 THEN 2  
			ELSE 3 END  
	ORDER By WorkCenter,DateBegin,Shift

END


GO

