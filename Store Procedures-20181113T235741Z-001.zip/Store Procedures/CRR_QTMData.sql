USE [MXReports]
GO

/****** Object:  StoredProcedure [dbo].[CRR_QTMData]    Script Date: 22/10/2018 11:30:09 a. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Flores, Adriana
-- Create date: Agust, 2018
-- Description:	QTM's Data, CRR
-- =============================================
CREATE PROCEDURE [dbo].[CRR_QTMData]
	@dtBegin datetime,@dtLast datetime
AS
BEGIN
	SET NOCOUNT ON;

	    SELECT 
			Substring(Machine,2,2) Machine 
			,count(*)Total
			,DATEPART( wk, @dtBegin) WeekNo,
			--CONVERT(VARCHAR(10), R.dtDate, 120) DateBegin,
			CONVERT(VARCHAR(10), R.dtDate, 111) DateBegin,
			CONVERT(VARCHAR(10), R.dtDate, 111) DateEnd,
			CASE  WHEN    DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) < 23400 THEN 3  
					WHEN DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) >= 23400 AND DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) < 52200 THEN 1  
					WHEN DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) >= 52200 AND DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) < 81000 THEN 2  
					ELSE 3 END  Shift
		FROM QTMsData.dbo.Results R
		WHERE R.dtDate between @dtBegin and @dtLast 
			and R.SampleNum=5
		GROUP BY Machine,
				CONVERT(VARCHAR(10), R.dtDate, 111),
				 CASE  WHEN    DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) < 23400 THEN 3  
					WHEN DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) >= 23400 AND DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) < 52200 THEN 1  
					WHEN DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) >= 52200 AND DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) < 81000 THEN 2  
					ELSE 3 END  
		UNION
		SELECT 
			Substring(Machine,2,2) Machine 
			,count(*)Total
			,DATEPART( wk, @dtBegin) WeekNo,
			CONVERT(VARCHAR(10), R.dtDate, 111) DateBegin,
			CONVERT(VARCHAR(10), R.dtDate, 111) DateEnd,
			CASE  WHEN    DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) < 23400 THEN 3  
					WHEN DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) >= 23400 AND DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) < 52200 THEN 1  
					WHEN DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) >= 52200 AND DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) < 81000 THEN 2  
					ELSE 3 END  Shift
		FROM QTMsData.dbo.Results_bkup R
		WHERE R.dtDate between @dtBegin and @dtLast 
			and R.SampleNum=5
		GROUP BY Machine,
				CONVERT(VARCHAR(10), R.dtDate, 111),
				 CASE  WHEN    DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) < 23400 THEN 3  
					WHEN DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) >= 23400 AND DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) < 52200 THEN 1  
					WHEN DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) >= 52200 AND DATEPART(SECOND , R.dtDate) + (DATEPART(MINUTE, R.dtDate) * 60) + (DATEPART(HOUR , R.dtDate) * 60 * 60) < 81000 THEN 2  
					ELSE 3 END  

END

GO

